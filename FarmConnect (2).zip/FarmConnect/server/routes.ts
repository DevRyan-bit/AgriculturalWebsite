import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactSchema, insertWeatherForecastSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Contact form submission
  app.post("/api/contact", async (req, res) => {
    try {
      const contactData = insertContactSchema.parse(req.body);
      const contact = await storage.createContact(contactData);
      res.json({ success: true, contact });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid contact data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to submit contact form" });
      }
    }
  });

  // Weather forecast endpoint
  app.post("/api/weather", async (req, res) => {
    try {
      const { location } = req.body;
      
      if (!location || typeof location !== 'string') {
        return res.status(400).json({ error: "Location is required" });
      }

      // Check if we have cached forecast data
      const cachedForecast = await storage.getWeatherForecastByLocation(location);
      if (cachedForecast) {
        const forecastAge = Date.now() - cachedForecast.createdAt!.getTime();
        // Use cached data if less than 1 hour old
        if (forecastAge < 3600000) {
          return res.json({ forecast: JSON.parse(cachedForecast.forecastData) });
        }
      }

      // Get weather API key from environment
      const apiKey = process.env.OPENWEATHER_API_KEY || process.env.WEATHER_API_KEY;
      if (!apiKey) {
        return res.status(500).json({ error: "Weather API key not configured" });
      }

      // Fetch weather data from OpenWeatherMap API
      const weatherResponse = await fetch(
        `https://api.openweathermap.org/data/2.5/forecast?q=${encodeURIComponent(location)}&appid=${apiKey}&units=imperial`
      );

      if (!weatherResponse.ok) {
        if (weatherResponse.status === 404) {
          return res.status(404).json({ error: "Location not found" });
        }
        throw new Error(`Weather API error: ${weatherResponse.status}`);
      }

      const weatherData = await weatherResponse.json();
      
      // Process the 5-day forecast data
      const forecastDays = [];
      const today = new Date();
      
      for (let i = 0; i < 5; i++) {
        const date = new Date(today);
        date.setDate(date.getDate() + i);
        
        // Find forecast for this day (around noon)
        const dayForecast = weatherData.list.find((item: any) => {
          const itemDate = new Date(item.dt * 1000);
          return itemDate.getDate() === date.getDate() && itemDate.getHours() >= 12;
        }) || weatherData.list[i * 8] || weatherData.list[0]; // Fallback to every 8th item (daily) or first

        if (dayForecast) {
          forecastDays.push({
            date: date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' }),
            temperature: Math.round(dayForecast.main.temp),
            condition: dayForecast.weather[0].main,
            description: dayForecast.weather[0].description,
            humidity: dayForecast.main.humidity,
            windSpeed: Math.round(dayForecast.wind.speed),
            icon: dayForecast.weather[0].icon
          });
        }
      }

      const forecastResult = {
        location: weatherData.city.name,
        country: weatherData.city.country,
        days: forecastDays
      };

      // Cache the forecast data
      await storage.createWeatherForecast({
        location,
        forecastData: JSON.stringify(forecastResult)
      });

      res.json({ forecast: forecastResult });
    } catch (error) {
      console.error("Weather API error:", error);
      res.status(500).json({ error: "Failed to fetch weather data" });
    }
  });

  // Get all contacts (for admin purposes)
  app.get("/api/contacts", async (req, res) => {
    try {
      const contacts = await storage.getContacts();
      res.json(contacts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch contacts" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
