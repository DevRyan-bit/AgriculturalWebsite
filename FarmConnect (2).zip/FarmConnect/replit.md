# Project Overview

## Overview

This is a full-stack React application for GreenField Agriculture, a company focused on sustainable farming practices. The application serves as a multi-page website with a contact form, weather forecast feature, and animated sections showcasing the company's mission and values. It's built using modern web technologies with a client-server architecture and includes a 3D weather visualization component.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **Routing**: Wouter for client-side routing (lightweight alternative to React Router)
- **Styling**: Tailwind CSS with CSS custom properties for theming
- **UI Components**: Shadcn/ui component library built on Radix UI primitives
- **Animation**: Framer Motion for smooth page transitions and scroll-triggered animations
- **State Management**: TanStack Query for server state management
- **3D Graphics**: Three.js for interactive weather visualizations

The frontend is organized with a clean component structure:
- Pages for different routes (home, contact, weather, 404)
- Reusable components (hero, about, mission, values sections)
- UI component library with consistent design system
- Custom hooks for mobile detection and toast notifications

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Storage**: Hybrid approach with in-memory storage for development and PostgreSQL schema for production
- **API Design**: RESTful endpoints for contact form submission and weather data
- **Session Management**: Express sessions with PostgreSQL session store

The server uses a layered architecture:
- Route handlers for API endpoints
- Storage abstraction layer for database operations
- Shared schema definitions between client and server
- Input validation using Zod schemas

### Data Storage Solutions
- **Primary Database**: PostgreSQL with Neon serverless database
- **ORM**: Drizzle ORM with type-safe schema definitions
- **Schema Management**: Database migrations with drizzle-kit
- **Development Storage**: In-memory storage implementation for testing
- **Session Storage**: PostgreSQL session store for user sessions

Database schema includes:
- Users table for authentication
- Contacts table for form submissions
- Weather forecasts table for caching API responses

### External Dependencies
- **Weather API**: OpenWeatherMap API for 5-day weather forecasts
- **Database**: Neon PostgreSQL serverless database
- **Fonts**: Google Fonts (Inter, DM Sans, Fira Code, Geist Mono, Architects Daughter)
- **Icons**: Lucide React icon library
- **Development Tools**: Replit-specific plugins for development environment

The application implements caching for weather data to reduce API calls and improve performance. Weather forecasts are cached for 1 hour before making new API requests.

### Build and Deployment
- **Development**: Vite dev server with HMR and TypeScript compilation
- **Production Build**: ESBuild for server bundling, Vite for client bundling
- **Asset Management**: Vite handles client-side assets with path resolution
- **Environment Configuration**: Environment variables for database URL and API keys

The build process creates optimized bundles for both client and server code, with the client assets served statically in production.