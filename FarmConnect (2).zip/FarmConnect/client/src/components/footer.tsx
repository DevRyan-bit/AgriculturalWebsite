import { motion } from "framer-motion";
import { Sprout } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-secondary text-secondary-foreground py-12" data-testid="footer">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="space-y-4"
            data-testid="footer-brand"
          >
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                <Sprout className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold">GreenField</span>
            </div>
            <p className="text-secondary-foreground/80">
              Cultivating sustainable solutions for tomorrow's harvest through innovation and expertise.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            data-testid="footer-quick-links"
          >
            <h3 className="font-semibold mb-4">Quick Links</h3>
            <div className="space-y-2">
              <a href="#home" className="block text-secondary-foreground/80 hover:text-secondary-foreground transition-colors" data-testid="footer-link-home">Home</a>
              <a href="#about" className="block text-secondary-foreground/80 hover:text-secondary-foreground transition-colors" data-testid="footer-link-about">About Us</a>
              <a href="#mission" className="block text-secondary-foreground/80 hover:text-secondary-foreground transition-colors" data-testid="footer-link-mission">Our Mission</a>
              <a href="#values" className="block text-secondary-foreground/80 hover:text-secondary-foreground transition-colors" data-testid="footer-link-values">Our Values</a>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            data-testid="footer-services"
          >
            <h3 className="font-semibold mb-4">Services</h3>
            <div className="space-y-2">
              <span className="block text-secondary-foreground/80">Crop Consulting</span>
              <span className="block text-secondary-foreground/80">Soil Analysis</span>
              <span className="block text-secondary-foreground/80">Weather Forecasting</span>
              <span className="block text-secondary-foreground/80">Equipment Leasing</span>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            data-testid="footer-contact"
          >
            <h3 className="font-semibold mb-4">Contact Info</h3>
            <div className="space-y-2 text-secondary-foreground/80">
              <p>123 Green Valley Road</p>
              <p>Farm District, AG 12345</p>
              <p>+1 (555) 123-FARM</p>
              <p>hello@greenfield-agriculture.com</p>
            </div>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="border-t border-secondary-foreground/20 mt-8 pt-8 text-center"
          data-testid="footer-copyright"
        >
          <p className="text-secondary-foreground/60">
            © 2024 GreenField Agriculture. All rights reserved. | Cultivating Excellence Since 1990
          </p>
        </motion.div>
      </div>
    </footer>
  );
}
