import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Sprout, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Navbar() {
  const [location] = useLocation();
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navItems = [
    { href: "/", label: "Home" },
    { href: "/contact", label: "Contact" },
    { href: "/weather", label: "Weather" },
  ];

  const scrollToSection = (sectionId: string) => {
    if (location === "/") {
      const element = document.getElementById(sectionId);
      if (element) {
        element.scrollIntoView({ behavior: "smooth" });
      }
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 py-4 ${
        isScrolled ? "navbar-blur" : ""
      }`}
      data-testid="navbar"
    >
      <div className="container mx-auto px-6 flex justify-between items-center">
        <Link href="/" data-testid="link-home">
          <motion.div
            whileHover={{ scale: 1.05 }}
            className="flex items-center space-x-2 cursor-pointer"
          >
            <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
              <Sprout className="w-6 h-6 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold text-primary">GreenField</span>
          </motion.div>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex space-x-8">
          {navItems.map((item) => (
            <Link key={item.href} href={item.href} data-testid={`link-${item.label.toLowerCase()}`}>
              <motion.span
                whileHover={{ scale: 1.05 }}
                className={`text-foreground hover:text-primary transition-colors duration-300 cursor-pointer ${
                  location === item.href ? "text-primary font-semibold" : ""
                }`}
              >
                {item.label}
              </motion.span>
            </Link>
          ))}
          {location === "/" && (
            <>
              <motion.button
                whileHover={{ scale: 1.05 }}
                onClick={() => scrollToSection("about")}
                className="text-foreground hover:text-primary transition-colors duration-300"
                data-testid="button-about"
              >
                About Us
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                onClick={() => scrollToSection("mission")}
                className="text-foreground hover:text-primary transition-colors duration-300"
                data-testid="button-mission"
              >
                Our Mission
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                onClick={() => scrollToSection("values")}
                className="text-foreground hover:text-primary transition-colors duration-300"
                data-testid="button-values"
              >
                Our Values
              </motion.button>
            </>
          )}
        </div>

        {/* Mobile Menu Button */}
        <Button
          variant="ghost"
          size="icon"
          className="md:hidden"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          data-testid="button-mobile-menu"
        >
          {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </Button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white shadow-lg mt-2 mx-6 rounded-lg overflow-hidden"
            data-testid="mobile-menu"
          >
            {navItems.map((item) => (
              <Link key={item.href} href={item.href} data-testid={`mobile-link-${item.label.toLowerCase()}`}>
                <div
                  className="block px-6 py-3 text-foreground hover:bg-muted transition-colors cursor-pointer"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {item.label}
                </div>
              </Link>
            ))}
            {location === "/" && (
              <>
                <button
                  onClick={() => scrollToSection("about")}
                  className="block w-full text-left px-6 py-3 text-foreground hover:bg-muted transition-colors"
                  data-testid="mobile-button-about"
                >
                  About Us
                </button>
                <button
                  onClick={() => scrollToSection("mission")}
                  className="block w-full text-left px-6 py-3 text-foreground hover:bg-muted transition-colors"
                  data-testid="mobile-button-mission"
                >
                  Our Mission
                </button>
                <button
                  onClick={() => scrollToSection("values")}
                  className="block w-full text-left px-6 py-3 text-foreground hover:bg-muted transition-colors"
                  data-testid="mobile-button-values"
                >
                  Our Values
                </button>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
}
