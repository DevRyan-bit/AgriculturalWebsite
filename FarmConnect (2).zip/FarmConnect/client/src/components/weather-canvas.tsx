import { useEffect, useRef } from "react";

interface WeatherDay {
  date: string;
  temperature: number;
  condition: string;
  description: string;
  humidity: number;
  windSpeed: number;
  icon: string;
}

interface WeatherForecast {
  location: string;
  country: string;
  days: WeatherDay[];
}

interface WeatherCanvasProps {
  forecast: WeatherForecast | null;
}

export default function WeatherCanvas({ forecast }: WeatherCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sceneRef = useRef<any>(null);
  const rendererRef = useRef<any>(null);
  const animationRef = useRef<number>();

  useEffect(() => {
    if (!canvasRef.current || typeof window === 'undefined') return;

    // Dynamically import Three.js to avoid SSR issues
    import('three').then((THREE) => {
      const canvas = canvasRef.current!;
      const container = canvas.parentElement!;

      // Initialize Three.js scene
      const scene = new THREE.Scene();
      const camera = new THREE.PerspectiveCamera(75, container.offsetWidth / 400, 0.1, 1000);
      const renderer = new THREE.WebGLRenderer({ canvas, alpha: true });

      renderer.setSize(container.offsetWidth, 400);
      renderer.setClearColor(0x87CEEB, 0.1); // Light sky blue with transparency

      sceneRef.current = scene;
      rendererRef.current = renderer;

      // Create weather particles
      const particleGeometry = new THREE.SphereGeometry(0.02, 8, 8);
      const particles: any[] = [];

      // Create different particle types based on weather
      const createParticles = (type: string, count: number) => {
        let material: any;
        
        switch (type) {
          case 'rain':
            material = new THREE.MeshBasicMaterial({ color: 0x4A90E2, transparent: true, opacity: 0.8 });
            break;
          case 'snow':
            material = new THREE.MeshBasicMaterial({ color: 0xFFFFFF, transparent: true, opacity: 0.9 });
            break;
          case 'cloud':
            material = new THREE.MeshBasicMaterial({ color: 0xE0E0E0, transparent: true, opacity: 0.6 });
            break;
          default:
            material = new THREE.MeshBasicMaterial({ color: 0xFFF700, transparent: true, opacity: 0.7 });
        }

        for (let i = 0; i < count; i++) {
          const particle = new THREE.Mesh(particleGeometry, material);
          particle.position.set(
            (Math.random() - 0.5) * 20,
            (Math.random() - 0.5) * 10,
            (Math.random() - 0.5) * 20
          );
          
          // Add velocity for animation
          (particle as any).velocity = {
            x: (Math.random() - 0.5) * 0.02,
            y: type === 'rain' ? -0.05 : (Math.random() - 0.5) * 0.01,
            z: (Math.random() - 0.5) * 0.02
          };
          
          scene.add(particle);
          particles.push(particle);
        }
      };

      // Create weather based on forecast
      if (forecast && forecast.days.length > 0) {
        const mainCondition = forecast.days[0].condition.toLowerCase();
        
        if (mainCondition.includes('rain') || mainCondition.includes('drizzle')) {
          createParticles('rain', 100);
        } else if (mainCondition.includes('snow')) {
          createParticles('snow', 80);
        } else if (mainCondition.includes('cloud')) {
          createParticles('cloud', 60);
        } else {
          createParticles('sun', 40);
        }
      } else {
        // Default sunny particles
        createParticles('sun', 50);
      }

      // Add ambient light
      const ambientLight = new THREE.AmbientLight(0x404040, 0.6);
      scene.add(ambientLight);

      // Add directional light
      const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
      directionalLight.position.set(5, 5, 5);
      scene.add(directionalLight);

      camera.position.z = 15;

      // Animation loop
      const animate = () => {
        animationRef.current = requestAnimationFrame(animate);

        // Update particles
        particles.forEach((particle, index) => {
          const velocity = (particle as any).velocity;
          
          particle.position.x += velocity.x;
          particle.position.y += velocity.y;
          particle.position.z += velocity.z;

          // Reset particles that go out of bounds
          if (particle.position.y < -10) {
            particle.position.y = 10;
          }
          if (particle.position.x > 10 || particle.position.x < -10) {
            particle.position.x = (Math.random() - 0.5) * 20;
          }
          if (particle.position.z > 10 || particle.position.z < -10) {
            particle.position.z = (Math.random() - 0.5) * 20;
          }

          // Add floating motion
          particle.position.y += Math.sin(Date.now() * 0.001 + index) * 0.001;
          particle.rotation.x += 0.01;
          particle.rotation.y += 0.01;
        });

        renderer.render(scene, camera);
      };

      animate();

      // Handle window resize
      const handleResize = () => {
        const newWidth = container.offsetWidth;
        camera.aspect = newWidth / 400;
        camera.updateProjectionMatrix();
        renderer.setSize(newWidth, 400);
      };

      window.addEventListener('resize', handleResize);

      return () => {
        window.removeEventListener('resize', handleResize);
        if (animationRef.current) {
          cancelAnimationFrame(animationRef.current);
        }
        
        // Clean up Three.js objects
        particles.forEach((particle: any) => {
          scene.remove(particle);
          particle.geometry.dispose();
          if (Array.isArray(particle.material)) {
            particle.material.forEach((material: any) => material.dispose());
          } else {
            particle.material.dispose();
          }
        });
        
        renderer.dispose();
      };
    }).catch(error => {
      console.error('Failed to load Three.js:', error);
    });

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [forecast]);

  return (
    <div className="bg-gradient-to-br from-blue-200 to-green-200 rounded-xl overflow-hidden" data-testid="weather-canvas-container">
      <canvas 
        ref={canvasRef} 
        id="weather-canvas" 
        className="w-full h-96"
        data-testid="weather-canvas"
      />
    </div>
  );
}
