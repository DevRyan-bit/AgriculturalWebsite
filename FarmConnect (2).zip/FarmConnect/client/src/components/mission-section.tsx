import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { Target } from "lucide-react";

export default function MissionSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="mission" className="py-20 bg-muted/30" ref={ref} data-testid="mission-section">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
          transition={{ duration: 0.8 }}
          className="grid lg:grid-cols-2 gap-12 items-center"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={isInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.8 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="relative order-2 lg:order-1"
            data-testid="mission-image-container"
          >
            <img
              src="https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
              alt="Aerial view of organized crop fields with precision agriculture patterns"
              className="rounded-2xl shadow-2xl w-full"
              data-testid="mission-image"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0 }}
              animate={isInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0 }}
              transition={{ duration: 0.5, delay: 1.2 }}
              className="absolute -top-6 -left-6 w-24 h-24 bg-primary rounded-full flex items-center justify-center shadow-lg"
              data-testid="mission-accent-icon"
            >
              <Target className="w-12 h-12 text-primary-foreground" />
            </motion.div>
          </motion.div>

          <div className="space-y-6 order-1 lg:order-2">
            <motion.h2
              initial={{ opacity: 0, x: 50 }}
              animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 50 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-4xl md:text-5xl font-bold text-primary"
              data-testid="mission-title"
            >
              Our Mission
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="text-lg text-muted-foreground leading-relaxed"
              data-testid="mission-description"
            >
              To revolutionize agriculture through sustainable innovation, empowering farmers with the tools and knowledge
              needed to feed the world while preserving our planet's precious resources.
            </motion.p>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="text-lg text-muted-foreground leading-relaxed"
              data-testid="mission-description-2"
            >
              We strive to bridge the gap between traditional farming wisdom and modern agricultural science,
              creating solutions that are both economically viable and environmentally responsible.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ duration: 0.8, delay: 0.8 }}
              className="grid grid-cols-2 gap-4 pt-4"
              data-testid="mission-stats"
            >
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <div className="text-2xl font-bold text-primary" data-testid="stat-partner-farms">500+</div>
                <div className="text-sm text-muted-foreground">Partner Farms</div>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <div className="text-2xl font-bold text-primary" data-testid="stat-yield-increase">30%</div>
                <div className="text-sm text-muted-foreground">Yield Increase</div>
              </div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
