export interface WeatherApiResponse {
  location: string;
  country: string;
  days: Array<{
    date: string;
    temperature: number;
    condition: string;
    description: string;
    humidity: number;
    windSpeed: number;
    icon: string;
  }>;
}

export const getWeatherForecast = async (location: string): Promise<WeatherApiResponse> => {
  const response = await fetch('/api/weather', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ location }),
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Failed to fetch weather data');
  }

  const data = await response.json();
  return data.forecast;
};
