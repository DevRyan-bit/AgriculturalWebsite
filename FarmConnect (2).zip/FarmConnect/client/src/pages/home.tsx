import HeroSection from "@/components/hero-section";
import AboutSection from "@/components/about-section";
import MissionSection from "@/components/mission-section";
import ValuesSection from "@/components/values-section";
import Footer from "@/components/footer";

export default function Home() {
  return (
    <div className="min-h-screen" data-testid="home-page">
      <HeroSection />
      <AboutSection />
      <MissionSection />
      <ValuesSection />
      <Footer />
    </div>
  );
}
