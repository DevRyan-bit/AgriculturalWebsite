import { useState } from "react";
import { motion } from "framer-motion";
import { useMutation } from "@tanstack/react-query";
import { Sun, Cloud, CloudRain } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import WeatherCanvas from "@/components/weather-canvas";
import Footer from "@/components/footer";

interface WeatherDay {
  date: string;
  temperature: number;
  condition: string;
  description: string;
  humidity: number;
  windSpeed: number;
  icon: string;
}

interface WeatherForecast {
  location: string;
  country: string;
  days: WeatherDay[];
}

export default function Weather() {
  const { toast } = useToast();
  const [location, setLocation] = useState("");
  const [forecast, setForecast] = useState<WeatherForecast | null>(null);

  const weatherMutation = useMutation({
    mutationFn: async (location: string) => {
      const response = await apiRequest("POST", "/api/weather", { location });
      return response.json();
    },
    onSuccess: (data) => {
      setForecast(data.forecast);
      toast({
        title: "Weather forecast loaded",
        description: `5-day forecast for ${data.forecast.location}`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to get weather forecast",
        description: error.message || "Please check the location and try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!location.trim()) {
      toast({
        title: "Location required",
        description: "Please enter a location to get the forecast.",
        variant: "destructive",
      });
      return;
    }
    weatherMutation.mutate(location.trim());
  };

  const getWeatherIcon = (condition: string) => {
    switch (condition.toLowerCase()) {
      case "clear":
      case "sunny":
        return Sun;
      case "clouds":
      case "cloudy":
        return Cloud;
      case "rain":
      case "drizzle":
        return CloudRain;
      default:
        return Sun;
    }
  };

  const getWeatherColor = (condition: string) => {
    switch (condition.toLowerCase()) {
      case "clear":
      case "sunny":
        return "from-yellow-400 to-orange-500";
      case "clouds":
      case "cloudy":
        return "from-gray-400 to-gray-600";
      case "rain":
      case "drizzle":
        return "from-blue-400 to-blue-600";
      default:
        return "from-yellow-400 to-orange-500";
    }
  };

  return (
    <div className="min-h-screen pt-20 bg-background" data-testid="weather-page">
      <div className="py-20 bg-background">
        <div className="container mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-12"
            data-testid="weather-header"
          >
            <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">Weather Forecast</h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Get accurate 5-day weather forecasts to plan your agricultural activities with confidence.
            </p>
          </motion.div>

          <div className="max-w-4xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              data-testid="weather-input-section"
            >
              <Card className="p-8 shadow-lg mb-8">
                <CardContent className="p-0">
                  <form onSubmit={handleSubmit} className="flex flex-col md:flex-row gap-4" data-testid="weather-form">
                    <div className="flex-1">
                      <label className="block text-sm font-medium text-foreground mb-2">
                        Enter Location
                      </label>
                      <Input
                        type="text"
                        placeholder="Enter city name or ZIP code"
                        value={location}
                        onChange={(e) => setLocation(e.target.value)}
                        data-testid="input-location"
                      />
                    </div>
                    <div className="flex items-end">
                      <Button
                        type="submit"
                        disabled={weatherMutation.isPending}
                        className="px-8 py-3"
                        data-testid="button-get-forecast"
                      >
                        {weatherMutation.isPending ? "Loading..." : "Get Forecast"}
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
            </motion.div>

            {/* 3D Weather Visualization */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="bg-gradient-to-br from-blue-50 to-green-50 rounded-2xl p-8 shadow-lg mb-8"
              data-testid="weather-canvas-section"
            >
              <h3 className="text-2xl font-bold text-foreground mb-6 text-center">
                3D Weather Visualization
              </h3>
              <WeatherCanvas forecast={forecast} />
            </motion.div>

            {/* 5-Day Forecast Cards */}
            {forecast && (
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.6 }}
                className="grid grid-cols-1 md:grid-cols-5 gap-4"
                data-testid="forecast-cards"
              >
                {forecast.days.map((day, index) => {
                  const WeatherIcon = getWeatherIcon(day.condition);
                  const colorClass = getWeatherColor(day.condition);

                  return (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, delay: 0.8 + index * 0.1 }}
                      whileHover={{ y: -5 }}
                      data-testid={`forecast-card-${index}`}
                    >
                      <Card className="text-center shadow-lg">
                        <CardContent className="p-6">
                          <div className="text-sm font-medium text-muted-foreground mb-2">
                            {day.date}
                          </div>
                          <div className={`w-16 h-16 mx-auto mb-4 bg-gradient-to-br ${colorClass} rounded-full flex items-center justify-center`}>
                            <WeatherIcon className="w-8 h-8 text-white" />
                          </div>
                          <div className="text-2xl font-bold text-foreground mb-1" data-testid={`temperature-${index}`}>
                            {day.temperature}°F
                          </div>
                          <div className="text-sm text-muted-foreground mb-3" data-testid={`condition-${index}`}>
                            {day.condition}
                          </div>
                          <div className="text-xs text-muted-foreground space-y-1">
                            <div>Humidity: <span data-testid={`humidity-${index}`}>{day.humidity}%</span></div>
                            <div>Wind: <span data-testid={`wind-${index}`}>{day.windSpeed} mph</span></div>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  );
                })}
              </motion.div>
            )}
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
